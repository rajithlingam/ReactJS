
const aboutUsData = [
  {
    username: "rajithlingam",
    role: "Frontend Developer",
    linkedin: "https://www.linkedin.com/in/rajithlingam-v-320909240/",
  },
  {
    username: "john_doe",
    role: "Full Stack Developer",
    linkedin: "https://www.linkedin.com/in/john-doe/",
  },
  {
    username: "jane_smith",
    role: "UI/UX Designer",
    linkedin: "https://www.linkedin.com/in/jane-smith/",
  },
  {
    username: "michael_brown",
    role: "Software Engineer",
    linkedin: "https://www.linkedin.com/in/michael-brown/",
  },
  {
    username: "sophia_white",
    role: "Product Manager",
    linkedin: "https://www.linkedin.com/in/sophia-white/",
  },
  {
    username: "david_johnson",
    role: "Backend Developer",
    linkedin: "https://www.linkedin.com/in/david-johnson/",
  },
  {
    username: "emma_wilson",
    role: "QA Engineer",
    linkedin: "https://www.linkedin.com/in/emma-wilson/",
  },
  {
    username: "william_taylor",
    role: "DevOps Engineer",
    linkedin: "https://www.linkedin.com/in/william-taylor/",
  },
  {
    username: "olivia_martin",
    role: "Data Scientist",
    linkedin: "https://www.linkedin.com/in/olivia-martin/",
  },
  {
    username: "noah_clark",
    role: "Cybersecurity Analyst",
    linkedin: "https://www.linkedin.com/in/noah-clark/",
  },
];

export default aboutUsData;