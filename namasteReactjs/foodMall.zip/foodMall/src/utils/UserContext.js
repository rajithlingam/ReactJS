import { createContext } from "react";

const UserContext = createContext({
  name: "Guest",
});
export default UserContext;
