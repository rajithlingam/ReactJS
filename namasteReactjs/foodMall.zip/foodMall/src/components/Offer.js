const Offer = () => {
  return (
    <div className="Offer">
      <h1>Welcome to FoodMall</h1>
    </div>
  );
};

export default Offer;
