const Shimmer = () => {
  return (
    <div className="card">
      <div className="subCard">
        <div className="shimmer shimmer-image"></div>
        <div className="shimmer shimmer-text"></div>
        <div className="shimmer shimmer-text small"></div>
      </div>
      <div className="subCard">
        <div className="shimmer shimmer-image"></div>
        <div className="shimmer shimmer-text"></div>
        <div className="shimmer shimmer-text small"></div>
      </div>
      <div className="subCard">
        <div className="shimmer shimmer-image"></div>
        <div className="shimmer shimmer-text"></div>
        <div className="shimmer shimmer-text small"></div>
      </div>
      <div className="subCard">
        <div className="shimmer shimmer-image"></div>
        <div className="shimmer shimmer-text"></div>
        <div className="shimmer shimmer-text small"></div>
      </div>
      <div className="subCard">
        <div className="shimmer shimmer-image"></div>
        <div className="shimmer shimmer-text"></div>
        <div className="shimmer shimmer-text small"></div>
      </div>
      <div className="subCard">
        <div className="shimmer shimmer-image"></div>
        <div className="shimmer shimmer-text"></div>
        <div className="shimmer shimmer-text small"></div>
      </div>
      <div className="subCard">
        <div className="shimmer shimmer-image"></div>
        <div className="shimmer shimmer-text"></div>
        <div className="shimmer shimmer-text small"></div>
      </div>
      <div className="subCard">
        <div className="shimmer shimmer-image"></div>
        <div className="shimmer shimmer-text"></div>
        <div className="shimmer shimmer-text small"></div>
      </div>
      <div className="subCard">
        <div className="shimmer shimmer-image"></div>
        <div className="shimmer shimmer-text"></div>
        <div className="shimmer shimmer-text small"></div>
      </div>
      <div className="subCard">
        <div className="shimmer shimmer-image"></div>
        <div className="shimmer shimmer-text"></div>
        <div className="shimmer shimmer-text small"></div>
      </div>
      <div className="subCard">
        <div className="shimmer shimmer-image"></div>
        <div className="shimmer shimmer-text"></div>
        <div className="shimmer shimmer-text small"></div>
      </div>
      <div className="subCard">
        <div className="shimmer shimmer-image"></div>
        <div className="shimmer shimmer-text"></div>
        <div className="shimmer shimmer-text small"></div>
      </div>
      <div className="subCard">
        <div className="shimmer shimmer-image"></div>
        <div className="shimmer shimmer-text"></div>
        <div className="shimmer shimmer-text small"></div>
      </div>
      <div className="subCard">
        <div className="shimmer shimmer-image"></div>
        <div className="shimmer shimmer-text"></div>
        <div className="shimmer shimmer-text small"></div>
      </div>
      <div className="subCard">
        <div className="shimmer shimmer-image"></div>
        <div className="shimmer shimmer-text"></div>
        <div className="shimmer shimmer-text small"></div>
      </div>
      <div className="subCard">
        <div className="shimmer shimmer-image"></div>
        <div className="shimmer shimmer-text"></div>
        <div className="shimmer shimmer-text small"></div>
      </div>
      <div className="subCard">
        <div className="shimmer shimmer-image"></div>
        <div className="shimmer shimmer-text"></div>
        <div className="shimmer shimmer-text small"></div>
      </div>
      <div className="subCard">
        <div className="shimmer shimmer-image"></div>
        <div className="shimmer shimmer-text"></div>
        <div className="shimmer shimmer-text small"></div>
      </div>
      <div className="subCard">
        <div className="shimmer shimmer-image"></div>
        <div className="shimmer shimmer-text"></div>
        <div className="shimmer shimmer-text small"></div>
      </div>
      <div className="subCard">
        <div className="shimmer shimmer-image"></div>
        <div className="shimmer shimmer-text"></div>
        <div className="shimmer shimmer-text small"></div>
      </div>
    </div>
  );
};

export default Shimmer;
